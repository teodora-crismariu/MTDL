package application;

import connectivity.ConnectionClass;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;

import java.sql.*;

public class Controller {
 
	public TextField nomutilisateur;
	public PasswordField motPasse;
	
	public void Button(ActionEvent actionEvent) throws SQLException {
		
		ConnectionClass connectionClass=new ConnectionClass();
		Connection connection=connectionClass.getConnection();
		String sql="INSERT INTO LOGIN VALUES('"+nomutilisateur.getText()+"')";
		Statement statement=connection.createStatement();
		statement.executeUpdate(sql);
	}
}
