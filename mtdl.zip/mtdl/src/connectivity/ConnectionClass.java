package connectivity;

import java.sql.*;
import java.sql.DriverManager;

public class ConnectionClass {
	public Connection connection;
	
	public Connection getConnection() {
		
		String dbName="mtdl";
		String userName="root";
		String password="";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		     connection=DriverManager.getConnection("jdbc:mysql://localhost/"+dbName,userName,password);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
}
